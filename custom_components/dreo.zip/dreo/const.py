"""Constants for Dreo Component."""

from homeassistant.const import Platform

DOMAIN = "dreo"

PLATFORMS = [Platform.FAN]
